﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class vilagbajnoksag
{
    public int ev {  get; set; }
    public string rendezo { get; set; }
    public string bajnok { get; set; }
}

namespace FociVB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LABDARÚGÓ-VILÁGBAJNOKSÁG");
            Console.WriteLine("========================");
            Console.WriteLine("Adatok feldolgozása: 1930-2022");

            List<vilagbajnoksag> vblista = new List<vilagbajnoksag>();

            string[] sorok = File.ReadAllLines("focivb.txt");

            foreach (string sor in sorok)
            {
                string[] adatok = sor.Split(';');

                vilagbajnoksag vb = new vilagbajnoksag();
                {
                    vb.ev = int.Parse(adatok[0]);
                    vb.rendezo = adatok[1];
                    vb.bajnok = adatok[2];

                    vblista.Add(vb);
                }

                Console.WriteLine("Az adatok beolvasása sikeres");
                Console.WriteLine();
                Console.WriteLine("Világbajnokságok száma: " + vblista.Count);

                var elso = vblista.OrderBy(x => x.ev).First();
                var utolso = vblista.OrderBy(x => x.ev).First();

                Console.WriteLine("Legkorábbi világbajnokság:");
                Console.WriteLine("Év: " + elso.ev);
                Console.WriteLine("Rendező: " + elso.rendezo);
                Console.WriteLine("Győztes: " + elso.bajnok);

                Console.WriteLine("Legkésőbbi világbajnokság:");
                Console.WriteLine("Év: " + utolso.ev);
                Console.WriteLine("Rendező: " + utolso.rendezo);
                Console.WriteLine("Győztes: " + utolso.bajnok);

                Console.Write("Adj meg egy évszámot: ");
                string beirtEV = Console.ReadLine();
                int keresettEv = Convert.ToInt32(beirtEV);

                bool talalt = false;

                foreach (var adat in vblista)
                {
                    if (adat.ev == keresettEv)
                    {
                        Console.WriteLine("Rendező ország: " + adat.rendezo);
                        Console.WriteLine("Világbajnok: " + adat.bajnok);

                        talalt = true;
                    }
                }

                if (talalt == false)
                {
                    Console.WriteLine("Ebben az évben nem volt világbajnokság!");
                }

                Console.WriteLine();
                Console.Write("Adj meg egy országnevet: ");
                string orszag = Console.ReadLine();

                int db = vblista.Count(x =>
                x.bajnok.Equals(orszag, StringComparison.OrdinalIgnoreCase));

                Console.WriteLine(orszag + " világbajnoki címeinek száma: " + db);


                Console.WriteLine();
                Console.WriteLine("Világbajnokságok csökkenő sorrendben:");

                vblista = vblista.OrderByDescending(x => x.ev).ToList();

                foreach (var adat in vblista) 
                {
                    Console.WriteLine(adat.ev + " " + adat.rendezo + " " + adat.bajnok);
                }

                    
                Console.WriteLine();
                Console.WriteLine("Hazai győzelmek:");

                var hazai = vblista.Where(x => x.rendezo == x.bajnok);

                foreach (var adat in hazai)
                {
                    Console.WriteLine(adat.ev + " - " + adat.rendezo);
                }


                List<string> eredmenyek = new List<string>();

                foreach (var adat in vblista)
                {
                    eredmenyek.Add(adat.ev + ";" + adat.rendezo + ";" + adat.bajnok);
                }

                File.WriteAllLines("eredmenyek.txt", eredmenyek);

                Console.WriteLine("Mentés sikeres!");



            }
        }
    }
}
